# Optional native Google Sign-In configuration

The Android build works without this folder's `google-services.json`; Google sign-in then remains disabled natively and the app keeps the normal web fallback.

To enable **real native Google Sign-In on Android** (required to avoid the WebView `missing initial state` error):

1. In Firebase Console, open project `jee2027-9d55a`.
2. Add/register an Android app with package name `com.vedplayer.jeetracker`.
3. Add the debug SHA-1 for the GitHub Actions debug build (or the SHA-1 of your release signing key later).
4. Enable Google under Firebase Authentication → Sign-in method.
5. Download `google-services.json`.
6. Put it here in this repository as:

   `firebase/google-services.json`

The GitHub Actions workflow detects the file automatically, copies it to `android/app/`, enables the native Google provider and builds the Android Firebase configuration.

**Do not paste API keys or client IDs into JavaScript.** The Android Firebase configuration belongs in `google-services.json`.
