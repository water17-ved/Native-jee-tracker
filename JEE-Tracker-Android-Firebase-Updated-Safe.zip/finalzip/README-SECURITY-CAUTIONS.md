# JEE Tracker Android — Security Cautions

## Safe configuration included
- `firebase/google-services.json` is the Firebase Android configuration.
- Firebase-provisioned API keys in this file are not treated as secrets when restricted to Firebase services.

## NEVER put these in this ZIP or Git repository
- Gemini Developer API keys
- OpenAI API keys
- Firebase/Google service-account private-key JSON files
- FCM server keys
- Release signing keystores (`.jks`, `.keystore`, `.p12`)
- Private keys/certificates (`.pem`, `.key`)
- `.env` files containing secrets
- GitHub personal access tokens or other access tokens
- Passwords, OAuth client secrets, database credentials, or private credentials

## Gemini
Keep Gemini API keys out of client-side source code and source-control ZIPs. Use GitHub Actions Secrets/environment variables or a secure backend/proxy for production.

## Firebase
Keep Firebase Security Rules and App Check configured correctly. `google-services.json` is different from a Firebase Admin/service-account private-key JSON file.

## GitHub Actions
If a secret is required during the build, store it in GitHub repository/environment Secrets. Do not write it into tracked files.

## Before sharing
Inspect the ZIP for accidental secrets before uploading it anywhere.
