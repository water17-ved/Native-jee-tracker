// JEE Tracker — Stage 7 offline/network resilience service worker.
// Local app data remains the source of truth; network-only services are never cached.
const CACHE_VERSION = 'jee-tracker-v2026-09-07-offline-v1';
const PRECACHE = [
  './', './index.html', './test-analysis.html', './schedule.html', './manifest.json',
  './ai-file-reader.js', './jee-native-storage.js', './jee-native-files.js',
  './jee-capacitor-bridge.js', './jee-android-hardening.js', './jee-ai-android.js',
  './jee-network-status.js'
];
const CDN_ORIGINS = ['cdnjs.cloudflare.com','cdn.jsdelivr.net','unpkg.com','fonts.googleapis.com','fonts.gstatic.com'];
const NETWORK_ONLY_HOSTS = [
  'generativelanguage.googleapis.com','api.openai.com','firebaseio.com','googleapis.com','google.com'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_VERSION).then(cache => cache.addAll(PRECACHE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

function isNetworkOnly(url){ return NETWORK_ONLY_HOSTS.some(h => url.hostname === h || url.hostname.endsWith('.'+h)); }
function cacheableResponse(r){ return r && r.ok && r.type !== 'opaque'; }

self.addEventListener('fetch', event => {
  const req = event.request;
  if(req.method !== 'GET') return;
  const url = new URL(req.url);
  if(isNetworkOnly(url)) return; // Gemini/OpenAI/Firebase must never be served from stale cache.

  if(CDN_ORIGINS.some(o => url.hostname === o || url.hostname.endsWith('.'+o))){
    event.respondWith(caches.open(CACHE_VERSION).then(cache =>
      cache.match(req).then(cached => cached || fetch(req).then(r => { if(cacheableResponse(r)) cache.put(req,r.clone()); return r; }))
    ));
    return;
  }

  if(url.origin === self.location.origin){
    event.respondWith(
      fetch(req).then(r => {
        if(cacheableResponse(r)) caches.open(CACHE_VERSION).then(c => c.put(req,r.clone()));
        return r;
      }).catch(() => caches.match(req).then(cached => cached || caches.match('./index.html')))
    );
  }
});

self.addEventListener('message', event => {
  if(event.data?.type === 'SKIP_WAITING') self.skipWaiting();
  if(event.data?.type === 'CLEAR_APP_CACHE') event.waitUntil(caches.delete(CACHE_VERSION));
});
