/* JEE Tracker — Stage 10 native Android services
 * Native JSON import/export, native scheduled notifications, native Google auth,
 * and a visible cross-page AI activity indicator. Browser fallbacks remain intact.
 */
(function(){
  'use strict';
  const isNative=()=>!!(window.Capacitor?.isNativePlatform?.());
  const plugins=()=>window.Capacitor?.Plugins||{};

  // ---------- Visible AI activity state ----------
  const AI_STATE='jee-ai-activity-state-v1';
  function readAI(){try{return JSON.parse(localStorage.getItem(AI_STATE)||'null')}catch(_){return null}}
  function writeAI(v){try{localStorage.setItem(AI_STATE,JSON.stringify(v));window.dispatchEvent(new CustomEvent('jee-ai-state-changed',{detail:v}))}catch(_){}
  }
  function setAI(patch){const cur=readAI()||{};writeAI({...cur,...patch,updatedAt:new Date().toISOString()})}
  window.JEEAIStatus={
    start(title,detail){setAI({active:true,title:title||'Gemini working',detail:detail||'Analysing tracker data…',startedAt:new Date().toISOString(),progress:0})},
    progress(progress,detail){setAI({active:true,progress:Math.max(0,Math.min(100,Number(progress)||0)),detail:detail||readAI()?.detail||'Working…'})},
    finish(title,detail,ok=true){setAI({active:false,progress:100,title:title||'AI finished',detail:detail||'',finishedAt:new Date().toISOString(),ok})},
    state:readAI
  };
  function mountAI(){
    if(document.getElementById('jee-ai-live'))return;
    const el=document.createElement('div');el.id='jee-ai-live';el.innerHTML='<div class="jee-ai-live-head"><span class="jee-ai-live-dot"></span><b id="jee-ai-live-title">AI idle</b><button id="jee-ai-live-close" type="button" aria-label="Hide">×</button></div><div class="jee-ai-live-detail" id="jee-ai-live-detail"></div><div class="jee-ai-live-track"><div id="jee-ai-live-fill"></div></div><div class="jee-ai-live-meta" id="jee-ai-live-meta"></div>';
    document.body.appendChild(el);
    document.getElementById('jee-ai-live-close')?.addEventListener('click',()=>el.classList.remove('show'));
    renderAI();
  }
  function renderAI(){
    const el=document.getElementById('jee-ai-live');if(!el)return;const s=readAI();if(!s)return;
    const title=document.getElementById('jee-ai-live-title'),detail=document.getElementById('jee-ai-live-detail'),fill=document.getElementById('jee-ai-live-fill'),meta=document.getElementById('jee-ai-live-meta');
    el.classList.add('show');el.classList.toggle('working',!!s.active);el.classList.toggle('done',!s.active&&s.ok!==false);el.classList.toggle('error',!s.active&&s.ok===false);
    if(title)title.textContent=s.active?(s.title||'Gemini working'):(s.ok===false?'AI stopped with an error':'AI finished');
    if(detail)detail.textContent=s.detail||'';
    if(fill)fill.style.width=(s.active?Number(s.progress||0):100)+'%';
    if(meta){const t=s.active&&s.startedAt?Math.max(0,Math.round((Date.now()-new Date(s.startedAt).getTime())/1000)):0;meta.textContent=s.active?`Working${t?` · ${t}s`:''}`:(s.finishedAt?`Last run ${new Date(s.finishedAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`:'');}
  }
  const style=document.createElement('style');style.textContent='#jee-ai-live{position:fixed;right:12px;top:12px;z-index:100000;width:min(330px,calc(100vw - 24px));padding:10px 12px;border:1px solid rgba(199,125,255,.55);border-radius:12px;background:rgba(16,9,20,.96);backdrop-filter:blur(14px);box-shadow:0 12px 35px rgba(0,0,0,.45);font:700 11px Roboto,sans-serif;display:none}#jee-ai-live.show{display:block}#jee-ai-live.working{border-color:#c77dff}#jee-ai-live.done{border-color:#39ff88}#jee-ai-live.error{border-color:#ff1a5e}.jee-ai-live-head{display:flex;align-items:center;gap:7px}.jee-ai-live-head b{flex:1;color:#fff}.jee-ai-live-dot{width:8px;height:8px;border-radius:50%;background:#39ff88;box-shadow:0 0 9px #39ff88}.working .jee-ai-live-dot{background:#c77dff;box-shadow:0 0 9px #c77dff;animation:jeeAiPulse 1s infinite}.jee-ai-live-head button{border:0;background:transparent;color:#8f7b9f;font-size:16px;line-height:1;cursor:pointer}.jee-ai-live-detail{margin-top:5px;color:#bba9c7;line-height:1.4}.jee-ai-live-track{height:4px;margin-top:8px;border-radius:99px;background:#25182c;overflow:hidden}.jee-ai-live-track>div{height:100%;width:0;background:linear-gradient(90deg,#c77dff,#ff3d7d,#39ff88);transition:width .25s}.jee-ai-live-meta{margin-top:5px;color:#77617f;font-size:9px}@keyframes jeeAiPulse{50%{opacity:.35;transform:scale(.7)}}@media(max-width:600px){#jee-ai-live{top:auto;bottom:74px;right:8px;width:calc(100vw - 16px)}}';document.head.appendChild(style);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mountAI);else setTimeout(mountAI,0);
  window.addEventListener('jee-ai-state-changed',renderAI);window.addEventListener('storage',e=>{if(e.key===AI_STATE)renderAI();});

  // ---------- Native JSON I/O ----------
  async function exportJSON(data,filename){
    if(!isNative())return false;
    const FS=plugins().Filesystem, Share=plugins().Share;if(!FS)return false;
    const safe=String(filename||'jee-tracker-backup.json').replace(/[^a-zA-Z0-9._-]+/g,'_');
    const base64=btoa(unescape(encodeURIComponent(JSON.stringify(data,null,2))));
    const path='jee-tracker/exports/'+safe;
    await FS.writeFile({path,directory:'CACHE',data:base64,recursive:true});
    const uri=await FS.getUri({path,directory:'CACHE'});
    if(Share){await Share.share({title:'JEE Tracker Backup',text:'JEE Tracker JSON backup',url:uri.uri,dialogTitle:'Save / share JEE Tracker backup'});return true;}
    return false;
  }
  async function pickJSON(){
    if(!isNative())return null;
    const Picker=plugins().FilePicker;if(!Picker)return null;
    const result=await Picker.pickFiles({types:['application/json','text/plain','application/octet-stream'],limit:1,readData:true});
    const f=result?.files?.[0];if(!f?.data)throw new Error('The selected backup could not be read.');
    const bin=atob(f.data);const bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));const text=new TextDecoder().decode(bytes);
    return {name:f.name||'backup.json',text};
  }
  window.JEEAndroidIO={isNative,exportJSON,pickJSON};

  // ---------- Native notifications ----------
  const LN=()=>plugins().LocalNotifications;
  async function notifPermission(){const p=LN();if(!p)throw new Error('Android notification service is unavailable.');let s=await p.checkPermissions();if(s.display!=='granted')s=await p.requestPermissions();if(s.display!=='granted')throw new Error('Notification permission was denied in Android settings.');return p;}
  async function scheduleDaily(slots){
    const p=await notifPermission();
    try{await p.createChannel({id:'jee-study',name:'JEE Study Reminders',description:'JEE Tracker study reminders',importance:4,sound:'default'});}catch(_){ }
    const ids=[4101,4102,4103];try{await p.cancel({notifications:ids.map(id=>({id}))});}catch(_){ }
    const notifications=[];
    for(let i=0;i<slots.length;i++){const s=slots[i];if(!s.enabled)continue;const [hour,minute]=String(s.time||'20:00').split(':').map(Number);notifications.push({id:ids[i],title:s.title,body:s.body,channelId:'jee-study',schedule:{on:{hour:Number(hour)||0,minute:Number(minute)||0},repeats:true,allowWhileIdle:true}})}
    if(notifications.length)await p.schedule({notifications});
    return notifications.length;
  }
  async function cancelDaily(){const p=LN();if(!p)return;try{await p.cancel({notifications:[4101,4102,4103].map(id=>({id}))});}catch(_){} }
  async function testNotification(){const p=await notifPermission();await p.schedule({notifications:[{id:4199,title:'JEE Tracker notifications are working ✓',body:'Native Android reminders are enabled.',channelId:'jee-study',schedule:{at:new Date(Date.now()+2500)}}]});return true;}
  window.JEEAndroidNotifications={available:()=>!!LN(),permission:notifPermission,scheduleDaily,cancelDaily,test:testNotification};
})();
