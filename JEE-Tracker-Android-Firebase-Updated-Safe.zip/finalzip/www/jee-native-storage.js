/* JEE Tracker — Stage 3 native persistence bridge
 *
 * Runtime compatibility layer:
 * - Existing application code continues to use localStorage unchanged.
 * - On Capacitor Android, localStorage is mirrored to an app-private JSON store
 *   through @capacitor/filesystem.
 * - On first launch after migration, native data is restored/merged safely.
 * - Browser/PWA behavior is unchanged.
 *
 * This is deliberately a compatibility migration, not a destructive rewrite.
 */
(function () {
  'use strict';

  const NATIVE_PATH = 'jee-tracker/storage-v1.json';
  const VERSION = 1;
  const RETRY_MS = 100;
  const MAX_RETRIES = 100;
  let retries = 0;
  let nativeReady = false;
  let writeTimer = null;
  let writeInFlight = Promise.resolve();
  let hydrating = false;
  let patched = false;

  function isNative() {
    try {
      return !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
    } catch (_) { return false; }
  }

  function getFS() {
    try { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Filesystem; }
    catch (_) { return null; }
  }

  function snapshotLocal() {
    const values = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && !k.startsWith('__jee_native_')) values[k] = localStorage.getItem(k);
      }
    } catch (_) {}
    return values;
  }

  function nativePayload(values) {
    return JSON.stringify({
      version: VERSION,
      updatedAt: new Date().toISOString(),
      values
    });
  }

  async function readNative(fs) {
    try {
      const r = await fs.readFile({ path: NATIVE_PATH, directory: 'DATA', encoding: 'utf8' });
      const text = typeof r.data === 'string' ? r.data : '';
      if (!text) return null;
      const parsed = JSON.parse(text);
      if (!parsed || parsed.version !== VERSION || !parsed.values || typeof parsed.values !== 'object') return null;
      return parsed;
    } catch (_) { return null; }
  }

  async function writeNativeNow() {
    if (!nativeReady) return;
    const fs = getFS();
    if (!fs) return;
    const payload = nativePayload(snapshotLocal());
    writeInFlight = writeInFlight.then(async () => {
      try {
        await fs.writeFile({
          path: NATIVE_PATH,
          directory: 'DATA',
          data: payload,
          encoding: 'utf8',
          recursive: true
        });
      } catch (e) {
        console.warn('[JEE] Native storage write failed:', e);
      }
    });
    return writeInFlight;
  }

  function scheduleNativeWrite() {
    if (!nativeReady) return;
    clearTimeout(writeTimer);
    writeTimer = setTimeout(() => { writeTimer = null; writeNativeNow(); }, 120);
  }

  function patchStorage() {
    if (patched || !isNative()) return;
    try {
      const proto = Storage.prototype;
      const originalSet = proto.setItem;
      const originalRemove = proto.removeItem;
      const originalClear = proto.clear;

      proto.setItem = function (key, value) {
        const result = originalSet.call(this, key, value);
        if (this === window.localStorage && !hydrating) scheduleNativeWrite();
        return result;
      };
      proto.removeItem = function (key) {
        const result = originalRemove.call(this, key);
        if (this === window.localStorage && !hydrating) scheduleNativeWrite();
        return result;
      };
      proto.clear = function () {
        const result = originalClear.call(this);
        if (this === window.localStorage && !hydrating) scheduleNativeWrite();
        return result;
      };
      patched = true;
    } catch (e) {
      console.warn('[JEE] Could not patch localStorage:', e);
    }
  }

  async function hydrate() {
    if (!isNative() || hydrating) return;
    const fs = getFS();
    if (!fs) return;
    hydrating = true;
    try {
      const native = await readNative(fs);
      const local = snapshotLocal();

      if (native) {
        // Native data is the durable baseline. Existing local values win so an
        // upgrade never silently overwrites data already present in the WebView.
        const merged = Object.assign({}, native.values, local);
        Object.keys(merged).forEach(k => {
          if (local[k] !== undefined) return;
          try { localStorage.setItem(k, merged[k]); } catch (_) {}
        });
        // Persist the merged state so the migration becomes self-healing.
      }
      nativeReady = true;
      // First run, or a merge after restoration: write the current durable snapshot.
      await writeNativeNow();
      window.__JEE_NATIVE_STORAGE_READY__ = true;
      window.dispatchEvent(new CustomEvent('jee-native-storage-ready', { detail: { version: VERSION, migrated: !!native } }));
      window.dispatchEvent(new Event('storage'));
    } finally {
      hydrating = false;
    }
  }

  function boot() {
    if (!isNative()) return;
    patchStorage();
    if (getFS()) {
      hydrate();
      return;
    }
    if (++retries < MAX_RETRIES) setTimeout(boot, RETRY_MS);
    else console.warn('[JEE] Filesystem plugin unavailable; localStorage remains the runtime fallback.');
  }

  if (isNative()) {
    window.__JEE_NATIVE_STORAGE_VERSION__ = VERSION;
    window.__JEE_NATIVE_STORAGE_READY__ = false;
    window.addEventListener('pagehide', () => { clearTimeout(writeTimer); writeNativeNow(); });
    window.addEventListener('jee-app-resumed', () => { if (nativeReady) hydrate(); });
    boot();
  }
})();
