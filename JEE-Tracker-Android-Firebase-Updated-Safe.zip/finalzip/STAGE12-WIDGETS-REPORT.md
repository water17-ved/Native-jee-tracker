# Stage 12 — Android Home-Screen Widgets

Added native Android home-screen widgets while preserving the existing JEE Tracker web UI.

## Widgets
- **JEE Tracker — Today:** questions, study hours, target/mission completion, streak, next mission.
- **JEE Tracker — Test Score:** latest analysed test score, accuracy and rank/percentile when available.
- **JEE Tracker — Next Mission:** compact focus widget showing the next unfinished Mission Centre block.

## Data flow
`index.html`, `schedule.html`, and `test-analysis.html` load `jee-widgets.js`. The bridge reads the existing shared tracker keys and sends a small widget state object to the native Capacitor plugin. The Android widget providers render that state using RemoteViews.

No Gemini API key, network request, or new account permission is required for widgets.

Widgets refresh when the app is active and on Android's periodic widget refresh cycle. Tapping a widget opens the relevant part of JEE Tracker.

## Build integration
The GitHub Actions workflow applies the native widget source after `npx cap add android` and before the Capacitor sync/build step. This keeps the source ZIP GitHub-ready without requiring Android Studio on the user's phone.
