from pathlib import Path
import shutil
root=Path('android')
src=Path('native-android/app')
for rel in ['src/main/java/com/vedplayer/jeetracker','src/main/res/layout','src/main/res/xml','src/main/res/drawable']:
    d=root/'app'/rel; d.mkdir(parents=True,exist_ok=True)
    s=src/rel
    for f in s.rglob('*'):
        if f.is_file():
            out=d/f.relative_to(s); out.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,out)
manifest=root/'app/src/main/AndroidManifest.xml'
s=manifest.read_text()
marker='<!-- JEE_TRACKER_WIDGETS -->'
if marker not in s:
    block=f'''\n        {marker}\n        <receiver android:name=".JeeWidgetProvider" android:label="JEE Tracker — Today" android:exported="false">\n            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="com.vedplayer.jeetracker.WIDGET_UPDATE"/></intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_jee_tracker_info"/>\n        </receiver>\n        <receiver android:name=".JeeMarksWidgetProvider" android:label="JEE Tracker — Test Score" android:exported="false">\n            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="com.vedplayer.jeetracker.WIDGET_UPDATE"/></intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_jee_marks_info"/>\n        </receiver>\n        <receiver android:name=".JeeFocusWidgetProvider" android:label="JEE Tracker — Next Mission" android:exported="false">\n            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="com.vedplayer.jeetracker.WIDGET_UPDATE"/></intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_jee_focus_info"/>\n        </receiver>\n'''
    s=s.replace('</application>',block+'    </application>')
    manifest.write_text(s)
