package com.vedplayer.jeetracker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.appwidget.AppWidgetManager;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "JEEWidgets")
public class JeeWidgetsPlugin extends Plugin {
    public static final String PREFS = "jee_widgets";
    public static final String STATE_KEY = "state";
    public static final String ACTION_UPDATE = "com.vedplayer.jeetracker.WIDGET_UPDATE";

    @com.getcapacitor.PluginMethod
    public void update(PluginCall call) {
        JSObject state = call.getObject("state", new JSObject());
        Context ctx = getContext();
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(STATE_KEY, state.toString()).apply();
        Intent i = new Intent(ctx, JeeWidgetProvider.class);
        i.setAction(ACTION_UPDATE);
        ctx.sendBroadcast(i);
        call.resolve();
    }

    public static String getState(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(STATE_KEY, "{}");
    }

    public static void refresh(Context ctx) {
        Intent i = new Intent(ctx, JeeWidgetProvider.class);
        i.setAction(ACTION_UPDATE);
        ctx.sendBroadcast(i);
    }
}
