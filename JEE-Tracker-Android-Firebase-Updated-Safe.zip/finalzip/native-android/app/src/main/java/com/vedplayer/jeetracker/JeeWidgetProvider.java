package com.vedplayer.jeetracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class JeeWidgetProvider extends AppWidgetProvider {
    private static final int FLAG = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (JeeWidgetsPlugin.ACTION_UPDATE.equals(intent.getAction())) {
            AppWidgetManager m = AppWidgetManager.getInstance(context);
            int[] ids = m.getAppWidgetIds(new ComponentName(context, JeeWidgetProvider.class));
            for (int id : ids) updateOne(context, m, id);
        }
    }

    private void updateOne(Context c, AppWidgetManager m, int id) {
        JSONObject s;
        try { s = new JSONObject(JeeWidgetsPlugin.getState(c)); } catch (Exception e) { s = new JSONObject(); }
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_jee_tracker);
        String date = s.optString("date", new SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(new Date()));
        v.setTextViewText(R.id.w_date, date.toUpperCase(Locale.getDefault()));
        v.setTextViewText(R.id.w_title, s.optString("title", "TODAY'S MISSION"));
        v.setTextViewText(R.id.w_questions, s.optString("questions", "0 / 0"));
        v.setTextViewText(R.id.w_hours, s.optString("hours", "0h 00m"));
        v.setTextViewText(R.id.w_streak, s.optString("streak", "0 days"));
        v.setTextViewText(R.id.w_next, s.optString("next", "No mission scheduled"));
        v.setProgressBar(R.id.w_progress, 100, Math.max(0, Math.min(100, s.optInt("progress", 0))), false);
        Intent launch = new Intent(c, MainActivity.class).putExtra("jee_page", "schedule");
        v.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(c, id, launch, FLAG));
        m.updateAppWidget(id, v);
    }
}
