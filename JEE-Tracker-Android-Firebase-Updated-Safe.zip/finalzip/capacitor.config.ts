import type { CapacitorConfig } from '@capacitor/cli';

const enableNativeGoogle = process.env.JEE_NATIVE_GOOGLE_AUTH === '1';

const config: CapacitorConfig = {
  appId: 'com.vedplayer.jeetracker',
  appName: 'JEE Tracker',
  webDir: 'www',
  bundledWebRuntime: false,
  plugins: {
    FirebaseAuthentication: {
      skipNativeAuth: false,
      providers: enableNativeGoogle ? ['google.com'] : []
    }
  },
  server: {
    androidScheme: 'https'
  }
};

export default config;
