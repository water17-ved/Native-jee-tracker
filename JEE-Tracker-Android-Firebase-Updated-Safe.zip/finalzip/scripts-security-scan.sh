#!/usr/bin/env bash
set -e
echo 'Scanning for likely secrets...'
if grep -RInE --exclude-dir=.git --exclude='google-services.json' '(AIza[0-9A-Za-z_-]{20,}|BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|GEMINI_API_KEY[[:space:]]*=[[:space:]]*[^$]|OPENAI_API_KEY[[:space:]]*=[[:space:]]*[^$])' .; then
  echo 'Potential secret found. Review before committing.'
  exit 1
fi
echo 'No obvious secret patterns found.'
