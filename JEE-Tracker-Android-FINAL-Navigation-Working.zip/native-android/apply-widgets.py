from pathlib import Path
import shutil


def install_launcher_icons():
    src_root = Path('native-android/launcher-icons')
    dst_root = Path('android/app/src/main/res')
    if not src_root.exists():
        return
    for src_dir in src_root.glob('mipmap-*'):
        dst_dir = dst_root / src_dir.name
        dst_dir.mkdir(parents=True, exist_ok=True)
        for name in ('ic_launcher.png', 'ic_launcher_round.png'):
            src_file = src_dir / name
            if src_file.exists():
                shutil.copy2(src_file, dst_dir / name)
root=Path('android')
src=Path('native-android/app')
for rel in ['src/main/java/com/vedplayer/jeetracker','src/main/res/layout','src/main/res/xml','src/main/res/drawable']:
    d=root/'app'/rel; d.mkdir(parents=True,exist_ok=True)
    s=src/rel
    for f in s.rglob('*'):
        if f.is_file():
            out=d/f.relative_to(s); out.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,out)
manifest=root/'app/src/main/AndroidManifest.xml'
s=manifest.read_text()
marker='<!-- JEE_TRACKER_WIDGETS -->'
if marker not in s:
    block=f'''\n        {marker}\n        <receiver android:name=".JeeWidgetProvider" android:label="JEE Tracker — Today" android:exported="false">\n            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="com.vedplayer.jeetracker.WIDGET_UPDATE"/></intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_jee_tracker_info"/>\n        </receiver>\n        <receiver android:name=".JeeMarksWidgetProvider" android:label="JEE Tracker — Test Score" android:exported="false">\n            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="com.vedplayer.jeetracker.WIDGET_UPDATE"/></intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_jee_marks_info"/>\n        </receiver>\n        <receiver android:name=".JeeFocusWidgetProvider" android:label="JEE Tracker — Next Mission" android:exported="false">\n            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="com.vedplayer.jeetracker.WIDGET_UPDATE"/></intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_jee_focus_info"/>\n        </receiver>\n'''
    s=s.replace('</application>',block+'    </application>')
    manifest.write_text(s)

install_launcher_icons()
