/* JEE Tracker — Stage 6 AI reliability layer
 * Shared request handling for Gemini/OpenAI inside Capacitor and normal browsers.
 * Never logs or persists API keys. Existing AI prompts and storage keys remain unchanged.
 */
(function(){
  'use strict';
  const native=!!(window.Capacitor?.isNativePlatform?.());
  const ACT='jee-ai-activity-log-v1';
  const MAX_RETRIES=2, TIMEOUT=45000;
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  function activity(entry){
    try{
      const a=JSON.parse(localStorage.getItem(ACT)||'[]');
      a.push({...entry,at:new Date().toISOString(),native});
      localStorage.setItem(ACT,JSON.stringify(a.slice(-100)));
    }catch(_){}
  }
  async function request(url,options,provider,model){
    let last;
    for(let attempt=0;attempt<=MAX_RETRIES;attempt++){
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),TIMEOUT);
      try{
        const r=await fetch(url,{...options,signal:controller.signal});
        clearTimeout(timer);
        let j=null; const text=await r.text();
        try{j=text?JSON.parse(text):null}catch(_){j=null}
        if(r.ok){activity({type:'ai-request',provider,model,status:'success'});return j||{}}
        const msg=j?.error?.message||j?.message||`Request failed (HTTP ${r.status})`;
        last=new Error(msg); last.status=r.status;
        const retryable=r.status===408||r.status===429||r.status>=500;
        if(!retryable||attempt===MAX_RETRIES){activity({type:'ai-request',provider,model,status:'error',httpStatus:r.status});throw last}
      }catch(e){
        clearTimeout(timer); last=e;
        const retryable=e?.name==='AbortError'||!e?.status;
        if(!retryable||attempt===MAX_RETRIES){
          activity({type:'ai-request',provider,model,status:'error',reason:e?.name||'network'});
          if(e?.name==='AbortError') throw new Error('AI request timed out. Check your connection and try again.');
          if(!e?.status) throw new Error('AI network request failed. Check your internet connection and try again.');
          throw e;
        }
      }
      await sleep(700*Math.pow(2,attempt));
    }
    throw last||new Error('AI request failed');
  }
  function geminiConfig(){return{provider:'gemini',key:(localStorage.getItem('jee-ai-api-key')||'').trim(),model:localStorage.getItem('jee-ai-model')||'gemini-3.8-flash'}}
  async function gemini(prompt,cfg){
    cfg=cfg||geminiConfig(); if(!navigator.onLine)throw new Error('Gemini requires an internet connection. Your offline tracker data is still available.'); if(!cfg.key)throw new Error('Configure a Gemini API key first.');
    const model=cfg.model||'gemini-3.8-flash';
    const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(cfg.key)}`;
    const j=await request(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:[{role:'user',parts:[{text:String(prompt||'')}]}]})},'gemini',model);
    const text=j?.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('')||'';
    if(!text)throw new Error(j?.promptFeedback?.blockReason?`Gemini blocked this request (${j.promptFeedback.blockReason}).`: 'Gemini returned no usable text.');
    return text;
  }
  async function openai(prompt,cfg){
    if(!navigator.onLine)throw new Error('OpenAI requires an internet connection. Your offline tracker data is still available.'); if(!cfg?.key)throw new Error('Configure an OpenAI API key first.');
    const model=cfg.model||'gpt-4.1-mini';
    const j=await request('https://api.openai.com/v1/responses',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+cfg.key},body:JSON.stringify({model,input:String(prompt||'')})},'openai',model);
    const text=j?.output_text||j?.output?.flatMap(x=>x.content||[]).map(x=>x.text||'').join('')||'';
    if(!text)throw new Error('OpenAI returned no usable text.'); return text;
  }
  window.JEEAIAndroid={native,request,gemini,openai,activity};
})();
