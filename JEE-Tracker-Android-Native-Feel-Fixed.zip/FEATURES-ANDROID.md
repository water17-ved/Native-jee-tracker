# JEE Tracker Android — Feature-complete build source

This package is prepared for Capacitor Android build.

## Native features included
- Native Firebase Google Sign-In on Android when the bundled Firebase config is valid.
- Capacitor Local Notifications with runtime permission, channel, daily schedules and test notification.
- Three Android home-screen widgets: Today, Test Score, Next Mission.
- Native JSON backup export/share and file-picker import.
- Exact supplied V logo converted to valid PNG assets for Android/PWA icons.
- GitHub Actions workflow extracts this ZIP first, then creates/syncs/builds the Android project.

## Firebase
The Android `google-services.json` is included under `firebase/` and is copied into `android/app/` during CI.
